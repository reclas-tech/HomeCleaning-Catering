<button type="submit" id="workingCompanies">
    <div class="w-[158px] h-[40px] py-2 rounded-md bg-[#0062D1] text-white text-center text-[14px] hover:bg-[#0062D1]">
        Save
    </div>
</button>

{{-- <script>
    const labelInput = document.getElementById("name");
    const addButton = document.getElementById("addButton");

    labelInput.addEventListener("input", () => {
        if (labelInput.value.trim() !== "") {
            addButton.style.visibility = "visible";
        } else {
            addButton.style.visibility = "hidden";
        }
    });
</script> --}}

<!-- <script>
    const workingCompanies = document.getElementById("workingCompanies");

    workingCompanies.addEventListener("click", () => {
        window.location.href = "cmsWorkingCompanies";
    });

</script> -->
