<div
    class="bg-[url(<?php echo e($imgPath); ?>)] w-full min-h-screen bg-cover bg-no-repeat bg-[#0062D1]/[0.46] bg-blend-overlay flex justify-center items-center">
    <div class="w-4/6 flex flex-col justify-center items-center">
        <h1 class="text-4xl md:text-6xl font-bold text-white text-center"><?php echo e($title); ?></h1>
        <p class="text-sm md:text-xl font-thin text-white text-center mt-4"><?php echo e($desc); ?></p>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cmsButton','data' => ['ref' => ''.e($ref).'','color' => '#FA8F21','width' => '[10rem]','title' => ''.e($butTitle).'','extendClass' => 'text-white text-center mt-6 py-3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cmsButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ref' => ''.e($ref).'','color' => '#FA8F21','width' => '[10rem]','title' => ''.e($butTitle).'','extendClass' => 'text-white text-center mt-6 py-3']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\Lingk\OneDrive\Documents\HomeCleaning-Catering\resources\views/components/heroTampilan.blade.php ENDPATH**/ ?>