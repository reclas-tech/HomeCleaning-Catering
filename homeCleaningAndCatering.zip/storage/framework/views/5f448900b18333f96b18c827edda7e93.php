<?php if($show==2): ?>
    <div class="m-4 w-72 bg-white shadow-lg rounded-lg">
        <h4 class="bg-[#0062D1] rounded-t-lg text-xl p-1 pl-4 text-white"><?php echo e($title); ?></h4>
        <div class="flex p-3">
            <div class="flex flex-col justify-center">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cmsButton','data' => ['ref' => ''.e($ref1).'','color' => '#FFFFFF','width' => '32','title' => ''.e($button1).'','extendClass' => 'ms-2 me-4 text-[#FA8F21] shadow-lg text-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cmsButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ref' => ''.e($ref1).'','color' => '#FFFFFF','width' => '32','title' => ''.e($button1).'','extendClass' => 'ms-2 me-4 text-[#FA8F21] shadow-lg text-semibold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?> 
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cmsButton','data' => ['ref' => ''.e($ref2).'','color' => '#FFFFFF','width' => '32','title' => ''.e($button2).'','extendClass' => 'ms-2 me-4 text-[#FA8F21] shadow-lg text-semibold']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cmsButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ref' => ''.e($ref2).'','color' => '#FFFFFF','width' => '32','title' => ''.e($button2).'','extendClass' => 'ms-2 me-4 text-[#FA8F21] shadow-lg text-semibold']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?> 
            </div>
            <div class="w-full flex justify-center items-center">
                <img class="p-2" src=<?php echo e(asset('assets/cmsAssets/'.$img.'.svg')); ?> alt="">
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="m-4 w-72 bg-white shadow-lg rounded-lg">
        <h4 class="bg-[#0062D1] rounded-t-lg text-xl p-1 pl-4 text-white"><?php echo e($title); ?></h4>
        <div class="flex p-3">
            <div class="flex flex-col justify-center">
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cmsButton','data' => ['ref' => ''.e($ref1).'','color' => '#FFFFFF','width' => '32','title' => ''.e($button1).'','extendClass' => 'ms-2 me-4 text-[#FA8F21] shadow-lg w-36']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cmsButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ref' => ''.e($ref1).'','color' => '#FFFFFF','width' => '32','title' => ''.e($button1).'','extendClass' => 'ms-2 me-4 text-[#FA8F21] shadow-lg w-36']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>  
            </div>
            <div class="w-full flex justify-center items-center text-semibold">
                <img class="p-2" src=<?php echo e(asset('assets/cmsAssets/'.$img.'.svg')); ?> alt="">
            </div>
        </div>
    </div>
<?php endif; ?><?php /**PATH C:\Users\Lingk\OneDrive\Documents\HomeCleaning-Catering\resources\views/components/cmsDashboardGroup.blade.php ENDPATH**/ ?>