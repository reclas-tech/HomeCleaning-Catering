<button type="submit" id="workingCompanies">
    <div class="w-[158px] h-[40px] py-2 rounded-md bg-[#0062D1] text-white text-center text-[14px] hover:bg-[#0062D1]">
        Save
    </div>
</button>



<!-- <script>
    const workingCompanies = document.getElementById("workingCompanies");

    workingCompanies.addEventListener("click", () => {
        window.location.href = "cmsWorkingCompanies";
    });

</script> -->
<?php /**PATH C:\Users\Lingk\OneDrive\Documents\HomeCleaning-Catering\resources\views/components/cmsButtonSave.blade.php ENDPATH**/ ?>