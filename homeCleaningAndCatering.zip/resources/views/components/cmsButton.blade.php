<a href="{{$ref}}" class="w-{{$width}} py-1 my-2 flex items-center justify-center rounded-md bg-[{{$color}}] {{$extendClass}}">
    {{$title}}
</a>
