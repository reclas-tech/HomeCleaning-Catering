<h1>Permisi, {{ $data['email'] }}</h1>
<p>Berikut ini Kode OTP anda : {{ $data['token'] }}</p>