<form action="{{ url() -> current() }}" method="GET">
    <div class="w-fit ms-2 border-2 border-{#AEAEAE} rounded-lg my-2 flex items-center overflow-hidden"> 
        <input type="text" id="search" name="search" class="border-none focus:ring-0 p-0.5 pl-2 w-32" placeholder="Search" value="{{ $value }}" >
        <button type="submit" class="p-0.5">
            <img class="" src={{ asset('assets/cmsAssets/searchButton.svg') }} alt="">
        </button>
    </div>
</form>