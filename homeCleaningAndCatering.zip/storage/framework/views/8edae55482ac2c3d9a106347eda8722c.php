<div class="mb-4">
    <p class="text-xl font-semibold mb-3"><?php echo e($label); ?></p>
    <div class="relative">
        <textarea id="<?php echo e($id); ?>" name="<?php echo e($id); ?>" rows="4" class="block px-2.5 pb-2.5 pt-4 w-full text-sm text-black bg-transparent rounded-lg border-1 border-gray-300 appearance-none dark:text-black dark:border-gray-600 dark:focus:border-bg-[#0062D1] focus:outline-none focus:ring-0 focus:border-bg-[#0062D1] peer"
        placeholder=" " oninvalid="this.setCustomValidity('Input is required'); alertInputRequired()" oninput="this.setCustomValidity('')" required ><?php echo e($value); ?></textarea>
        <label for="<?php echo e($id); ?>"
        class="absolute text-sm text-[#0062D1] dark:text-gray-400 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white px-2 peer-focus:px-2 peer-focus:text-[#0062D1] peer-focus:dark:text-[#0062D1] peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 left-1">
        <?php echo e($title); ?>

        </label>
    </div>
</div><?php /**PATH C:\Users\Lingk\OneDrive\Documents\HomeCleaning-Catering\resources\views/components/cmsTextArea.blade.php ENDPATH**/ ?>