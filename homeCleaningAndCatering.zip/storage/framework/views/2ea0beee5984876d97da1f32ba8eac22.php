<form action="<?php echo e(url() -> current()); ?>" method="GET">
    <div class="w-fit ms-2 border-2 border-{#AEAEAE} rounded-lg my-2 flex items-center overflow-hidden"> 
        <input type="text" id="search" name="search" class="border-none focus:ring-0 p-0.5 pl-2 w-32" placeholder="Search" value="<?php echo e($value); ?>" >
        <button type="submit" class="p-0.5">
            <img class="" src=<?php echo e(asset('assets/cmsAssets/searchButton.svg')); ?> alt="">
        </button>
    </div>
</form><?php /**PATH C:\Users\Lingk\OneDrive\Documents\HomeCleaning-Catering\resources\views/components/cmsSearch.blade.php ENDPATH**/ ?>