<a href="<?php echo e($ref); ?>" class="w-<?php echo e($width); ?> py-1 my-2 flex items-center justify-center rounded-md bg-[<?php echo e($color); ?>] <?php echo e($extendClass); ?>">
    <?php echo e($title); ?>

</a>
<?php /**PATH C:\Users\Lingk\OneDrive\Documents\HomeCleaning-Catering\resources\views/components/cmsButton.blade.php ENDPATH**/ ?>