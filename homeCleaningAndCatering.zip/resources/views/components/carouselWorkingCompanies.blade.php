<?php 
// $dataCompanies = [
                    // [
                    //     'logo' => asset('assets/tampilanAssets/dinasPendidikanKebudayaan.png'),
                    //     'nameTitle' => 'General Cleaning & Housekeeping',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/balitbangda.png'),
                    //     'nameTitle' => 'Asu 2',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/logo-puskesmas.png'),
                    //     'nameTitle' => 'Asu 3',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/Logo_PLN.png'),
                    //     'nameTitle' => 'Asu 4',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/Lambang_Kabupaten_Pesawaran.png'),
                    //     'nameTitle' => 'Asu 5',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/Logo_bank_Lampung_baru.png'),
                    //     'nameTitle' => 'Asu 6',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/Bank_Syariah_Mandiri_logo.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/pgn.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/Bank Indonesia.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/kristie-removebg-preview.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/LOGO_KOTA_BANDAR_LAMPUNG_BARU.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/surya_mustika_lampung-removebg-preview.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/Polinela_logo_color_400.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/Bank-Index.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/Omah_Akas-removebg-preview.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/bukit-asam-increase-coal-output-2017.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/auraderma.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/kusuma beauty clinic.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/english first.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/kosotel.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
                    // [
                    //     'logo' => asset('assets/tampilanAssets/andesit lumbung.png'),
                    //     'nameTitle' => 'Asu 7',
                    //     'desk' =>  'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry s standard dummy text ever since the',
                    // ],
// ];
?>

<div class="grid grid-cols-1">

@if (count($dataCompanies) == 1)

    <div class="relative">
        <div class="relative overflow-hidden md:h-80 flex bg-white rounded-lg">

            <div class="duration-700 ease-in-out flex gap-4 justify-center p-lg-5 p-sm-2 p-3 pt-[2%]"
                data-carousel-item="active">
                <div class="w-64 h-64 relative">
                    <img class="w-full h-64 absolute m-auto p-5" src="{{ $dataCompanies[0]['logo'] }}" alt="bg-profile" />
                </div>

            </div>

        </div>
    </div>

@elseif (count($dataCompanies) > 1 && count($dataCompanies) < 5)

    <div id="indicators-carousel" class="relative" data-carousel="slide">
        <div class="relative overflow-hidden md:h-80 flex bg-white rounded-lg">

            @foreach($dataCompanies as $index => $item)
            <div class="hidden duration-700 ease-in-out flex gap-4 justify-center p-lg-5 p-sm-2 p-3 pt-[2%]"
                data-carousel-item="active">
                <div class="w-64 h-64 relative">
                    <img class="w-full h-64 absolute m-auto p-5" src="{{ $item['logo'] }}" alt="bg-profile" />
                </div>

            </div>
            @endforeach

        </div>
    </div>

@elseif (count($dataCompanies) >= 5)

    <!-- mobile -->
    <div class="md:hidden">
        <div id="indicators-carousel" class="relative" data-carousel="slide">
            <div class="relative overflow-hidden md:h-80 flex bg-white rounded-lg">

                @foreach($dataCompanies as $index => $item)
                @if($index % 2 == 0)
                <div class="hidden duration-700 ease-in-out flex gap-4 justify-center p-lg-5 p-sm-2 p-3 pt-[2%]"
                    data-carousel-item="active">
                    @endif
                    <div class="w-64 h-64 relative">
                        <img class="w-full h-64 absolute m-auto p-5" src="{{ $item['logo'] }}" alt="bg-profile" />
                    </div>

                    @if($index % 2 == 0 || $index == count($dataCompanies) - 1)
                </div>
                @endif
                @endforeach

            </div>
        </div>
    </div>


    <!-- tablet -->
    <div class="hidden md:block lg:hidden">
        <div id="indicators-carousel" class="relative" data-carousel="slide">
            <div class="relative overflow-hidden md:h-80 bg-white rounded-lg">

                @foreach($dataCompanies as $index => $item)
                @if($index % 3 == 0)
                <div class="hidden duration-700 ease-in-out flex gap-4 justify-center p-lg-5 p-sm-2 p-3 pt-[2%]"
                    data-carousel-item="active">
                    @endif
                    <div class="w-64 h-64 relative">
                        <img class="w-full h-full absolute m-auto p-5" src="{{ $item['logo'] }}" alt="bg-profile" />
                    </div>

                    @if($index % 3 == 2 || $index == count($dataCompanies) - 1)
                </div>
                @endif
                @endforeach

            </div>
        </div>
    </div>

    <!-- Komputer -->
    <div class="hidden lg:block">
        <div id="indicators-carousel" class="relative" data-carousel="slide">
            <div class="relative overflow-hidden md:h-80 bg-white rounded-lg">

                @foreach($dataCompanies as $index => $item)
                @if($index % 4 == 0)
                <div class="hidden duration-700 ease-in-out flex gap-4 justify-center p-lg-5 p-sm-2 p-3 pt-[2%]"
                    data-carousel-item="active">
                    @endif
                    <div class="w-64 h-64 relative">
                        <img class="w-full h-full absolute m-auto p-5" src="{{ $item['logo'] }}" alt="bg-profile" />
                    </div>

                    @if($index % 4 == 3 || $index == count($dataCompanies) - 1)
                </div>
                @endif
                @endforeach

            </div>
        </div>
    </div>

@endif

</div>
