        <div class="w-1/2 bg-white h-full flex">
            <img src={{ asset('assets/img-autoritation.png') }} alt="bg-login"
                class="m-auto w-[451px] h[312px]" />
        </div>