<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cmsLayout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cmsLayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h1 class="text-3xl font-semibold p-2 mt-2">Catering Photo Gallery</h1>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cmsTable','data' => ['top' => ['Image'],'exception' => 'id','addRef' => '/cmsCateringPhotoAdd','test' => $test,'allPage' => $data -> lastPage(),'currentPage' => $data -> currentPage(),'prevPage' => $data -> previousPageUrl(),'nextPage' => $data -> nextPageUrl(),'search' => $varSearch]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cmsTable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['top' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['Image']),'exception' => 'id','addRef' => '/cmsCateringPhotoAdd','test' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($test),'allPage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data -> lastPage()),'currentPage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data -> currentPage()),'prevPage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data -> previousPageUrl()),'nextPage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($data -> nextPageUrl()),'search' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($varSearch)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

    <?php if(session()->has('successAddContent')): ?>
        <script>
            document.addEventListener("DOMContentLoaded", function(event) { 
                alertDataEnteredSuccessfully();
            });
        </script>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?><?php /**PATH C:\Users\Lingk\OneDrive\Documents\HomeCleaning-Catering\resources\views/cmsCateringPhoto.blade.php ENDPATH**/ ?>