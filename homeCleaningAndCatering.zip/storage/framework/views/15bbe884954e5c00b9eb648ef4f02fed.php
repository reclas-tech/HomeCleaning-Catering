<div class="flex justify-end my-2">
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cmsSearch','data' => ['value' => $search]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cmsSearch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($search)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.cmsButton','data' => ['ref' => ''.e($addRef).'','color' => '#FA8F21','width' => '32','title' => '+Add Data','extendClass' => 'ms-2 me-4 text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('cmsButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ref' => ''.e($addRef).'','color' => '#FA8F21','width' => '32','title' => '+Add Data','extendClass' => 'ms-2 me-4 text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?> 
</div>
<div class="relative overflow-x-auto"> 
    <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
        <thead class="text-xs text-gray-700 uppercase">
            <tr class="border-b-2 border-black">
                <th scope="col" class="px-5 py-3">
                    No
                </th>
                <?php $__currentLoopData = $top; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="col" class="px-6 py-3">
                        <?php echo e($thead); ?>

                    </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <th scope="col" class="px-6 py-3 text-center">
                    Action
                </th>
            </tr>
        </thead>
        <tbody>
            <?php if($test['data'] === [] ): ?>
                <tr class="">
                    <td colspan="<?php echo e(sizeof($top)+2); ?>" class="text-lg text-center">
                        <p class="p-2">There Is No Data</p>
                    </td>
                </tr>
            <?php else: ?>
                <?php for($i = 0; $i < sizeof($test['data']); $i++): ?>
                <tr class="bg-white border-b-2 border-black">
                <td class="px-5 py-4 text-gray-700 font-bold truncate text-center">
                    <?php echo e($i + 1 + (($currentPage - 1) * 10)); ?>

                </td>
                        <?php $__currentLoopData = $test['data'][$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($key !== $exception): ?>
                            <td class="px-6 py-4">
                                <p class="text-gray-700 font-semibold truncate max-w-[20rem]">
                                    <?php echo e($value); ?>

                                </p>
                            </td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-2.5 py-2 w-fit flex flex-row gap-1 items-center gap-x-3 w-full justify-center">
                            <a href="<?php echo e(url() -> current()); ?>/edit/<?php echo e($test['data'][$i]['id']); ?>" class="focus:outline-none text-white bg-yellow-400 hover:bg-yellow-500 focus:ring-4 focus:ring-yellow-300 font-medium rounded-lg text-sm px-3 py-2.5 dark:focus:ring-yellow-900">Edit</a>
                            <button value="<?php echo e($test['data'][$i]['id']); ?>" onclick="deleteData(this)" data-modal-target="popup-modal" data-modal-toggle="popup-modal" class="focus:outline-none text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 font-medium rounded-lg text-sm px-3 py-2.5 dark:bg-red-600 dark:hover:bg-red-700 dark:focus:ring-red-900">Delete</button>
                        </td>
                </tr>
                <?php endfor; ?>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="flex justify-center my-2">
        <nav aria-label="Page navigation example">
            <ul class="inline-flex -space-x-px text-sm">
              <li>
                <a <?php if($prevPage): ?> href="<?php echo e($prevPage); ?>" <?php endif; ?> class="flex items-center justify-center px-3 h-8 ml-0 leading-tight"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="13" viewBox="0 0 12 13" fill="none">
                    <path d="M11 1L2 6.5L11 12" stroke="#FA8F21" stroke-width="2"/>
                    </svg></a>
              </li>
              <?php if($currentPage - 2 > 1): ?>
                <li>
                    <a href="<?php echo e(url() -> current()); ?>?page=1" class="flex items-center justify-center px-3 h-8 leading-tight font-semibold">1</a>
                </li>
                <?php if($currentPage - 2 !== 1): ?>
                <li>
                    <p>...</p>
                </li>
                <?php endif; ?>
              <?php endif; ?>
              <?php for($i = 1; $i <= $allPage; $i++): ?>
                <?php if($i === $currentPage - 1 || $i === $currentPage + 1): ?>
                  <li>
                    <a href="<?php echo e(url() -> current()); ?>?page=<?php echo e($i); ?>" class="flex items-center justify-center px-3 h-8 leading-tight font-semibold"><?php echo e($i); ?></a>
                  </li>
                <?php elseif($i === $currentPage): ?>
                    <li>
                        <a class="flex items-center justify-center px-3 h-8 leading-tight font-semibold"><?php echo e($i); ?></a>
                    </li>
                <?php endif; ?>
              <?php endfor; ?>
              <?php if($currentPage + 2 < $allPage): ?>
                <?php if($currentPage + 2 !== $allPage): ?>
                <li>
                    <p>...</p>
                </li>
                <?php endif; ?>
                <li>
                    <a href="<?php echo e(url() -> current()); ?>?page=<?php echo e($allPage); ?>" class="flex items-center justify-center px-3 h-8 leading-tight font-semibold"><?php echo e($allPage); ?></a>
                </li>
              <?php endif; ?>
              <li>
                <a <?php if($nextPage): ?> href="<?php echo e($nextPage); ?>" <?php endif; ?> class="flex items-center justify-center px-3 h-8 ml-0 leading-tight"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="14" viewBox="0 0 15 14" fill="none">
                    <path d="M1 1L12 6.61441L1 12.2288" stroke="#FA8F21" stroke-width="2"/>
                    </svg></a>
              </li>
            </ul>
          </nav>
    </div>
</div>
<div id="popup-modal" tabindex="-1" class="fixed top-0 left-0 right-0 z-50 hidden p-2 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative w-full max-w-md max-h-full">
        <div class="relative bg-white rounded-lg shadow w-[28rem]">
            <div class="p-3 text-center">
                <div class="flex justify-between items-center mb-5 px-4">
                    <div class="flex justify-center items-center">
                        <img src=<?php echo e(asset('assets/tampilanAssets/trashLogo.svg')); ?> alt="">
                        <h3 class="ms-3 text-lg font-semibold">Are you sure to delete this data?</h3>
                    </div>
                    <button type="button" data-modal-hide="popup-modal">
                        <svg xmlns="http://www.w3.org/2000/svg" width="15" height="16" viewBox="0 0 15 16" fill="none">
                            <path d="M15.0001 1.70689L14.0094 0.716339L7.50004 7.22574L0.990643 0.716339L0 1.70689L6.50945 8.21634L0 14.7258L0.990643 15.7163L7.50004 9.20694L14.0094 15.7163L15.0001 14.7258L8.49064 8.21634L15.0001 1.70689Z" fill="#404040"/>
                        </svg>
                    </button>
                </div>
                <button onclick="dataDelete()" data-modal-hide="popup-modal" type="button" class="text-white bg-[#FF473E] font-medium rounded-lg text-sm inline-flex items-center px-10 py-2 text-center mr-2">
                    YES
                </button>
                <button data-modal-hide="popup-modal" type="button" class="text-white bg-[#1B62B8] font-medium rounded-lg text-sm inline-flex items-center px-10 py-2 text-center mr-2">NO</button>
            </div>
        </div>
    </div>
</div>

<script>
    let deleteIndex = null;
    function deleteData (elmnt) {
        deleteIndex = elmnt.getAttribute('value');
    }
    function dataDelete () {
        fetch(window.location.origin + window.location.pathname + "/" + deleteIndex).then((res) => res.json()).then((data) => {
            if (!data.status) {
                alertInputRequired('Delete data failed');
            } else {
                alertDataEditedSuccessfully('Delete data successfully');
                setTimeout(
                    function(){
                        window.location.reload();
                    }, 800);
            }
        });
    }
</script><?php /**PATH C:\Users\Lingk\OneDrive\Documents\HomeCleaning-Catering\resources\views/components/cmsTable.blade.php ENDPATH**/ ?>