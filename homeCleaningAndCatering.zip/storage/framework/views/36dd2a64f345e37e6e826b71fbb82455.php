<form action="<?php echo e(url('/register')); ?>" method="POST">
	<?php echo csrf_field(); ?>

	<input type="email" name="email">
	<input type="text" name="password">

	<button type="submit">REGISTER</button>

</form><?php /**PATH C:\Users\Lingk\OneDrive\Documents\HomeCleaning-Catering\resources\views/register.blade.php ENDPATH**/ ?>